ABOUT
-----

Queue implementation for kpcb

BUILD
-----

make testqueue -> to build the test executable.

make clean -> to clean the workspace
